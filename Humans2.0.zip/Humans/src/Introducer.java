public class Introducer {
	public static String createPublicIntroduction(Human person) {
		try {
		String pronoun = "They";
		String output = "I am pleased to introduce ";
		output = output + person.getFirstName() 
						+ " "
						+ person.getLastName() 
						+ ".";
		if (person.getGender() == Gender.FEMALE) {pronoun = "She";}
		else if (person.getGender() == Gender.MALE) {pronoun = "He";}
		if (person instanceof Youth) {
			output = output + " "
							+ pronoun
							+ " goes to "
							+ ((Youth) person).getSchoolName()
							+ " and is in grade "
							+ ((Youth)person).getSchoolGrade()
							+ ".";
			if (person instanceof WilliamAberhartStudent) {
				if (((WilliamAberhartStudent)person).getHoomRoomTeacher() != null) {
					output = output + " "
									+ pronoun
									+ " belongs to "
									+ ((WilliamAberhartStudent)person).getHoomRoomTeacher()
									+ "'s homeroom, which is in room "
									+ ((WilliamAberhartStudent)person).getHomeRoom()
									+ ".";
				} else {
					output += " Their homeroom is unknown at this time.";
				}
			}
		} else if (person instanceof Adult) {
			output = output + " "
							+ pronoun
							+ " works at "
							+ ((Adult)person).getPlaceOfWork()
							+ " and their occupation is "
							+ (((Adult)person).getOccupation())
							+ ".";
		} 
		return output.toString();
		} catch (Exception e) {return "This person has issues and can't be introduced.";}
	}
}
