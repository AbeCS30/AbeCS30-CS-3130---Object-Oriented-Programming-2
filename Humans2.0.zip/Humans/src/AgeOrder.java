import java.util.Comparator;

public class AgeOrder implements Comparator<Human>{
// If h1 is older return -1
	@Override
	public int compare(Human humanOne, Human humanTwo) {
		if (humanOne.getBirthYear() < humanTwo.getBirthYear() ) {return -1;}
		else if (humanOne.getBirthYear() > humanTwo.getBirthYear() ) {return 1;}
		else {
			if (humanOne.getBirthMonth() < humanTwo.getBirthMonth() ) {return -1;}
			else if (humanOne.getBirthMonth() > humanTwo.getBirthMonth() ) {return 1;}
			else {
				if (humanOne.getBirthDay() < humanTwo.getBirthDay() ) {return -1;}
				else if (humanOne.getBirthDay() > humanTwo.getBirthDay() ) {return 1;}
				else {return 0;}
			}
		}
	}
	
}
