import java.util.Comparator;

public class AssemblyOrder implements Comparator<Human>{

	@Override
	public int compare(Human o1, Human o2) {
		NameOrder sortByName = new NameOrder();
		int o1Value = getOrdinal(o1);
		int o2Value = getOrdinal(o2);
		if (o1Value == o2Value) {
			return sortByName.compare(o1, o2);
		} else if (o1Value > o2Value) {
			return 1;
		} else {
			return -1;
		}
	}
	private int getOrdinal(Human person) {
		if (person instanceof Adult) {
			return 2;
		} else if (person instanceof WilliamAberhartStudent) {
			return 0;
		} else if (person instanceof Youth) {
			return 1;
		} else {
			return 3;
		}
	}
	
}
