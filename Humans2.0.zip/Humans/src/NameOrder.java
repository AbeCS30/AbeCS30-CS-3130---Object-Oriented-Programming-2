import java.util.Comparator;

public class NameOrder implements Comparator<Human>{

	@Override
	public int compare(Human o1, Human o2) {
		String humanOneFirstName = o1.getFirstName();
		String humanTwoFirstName = o2.getFirstName();
		String humanOneLastName = o1.getLastName();
		String humanTwoLastName = o2.getLastName();
		if (humanOneLastName.compareTo(humanTwoLastName) == 0) {
			return humanOneFirstName.compareTo(humanTwoFirstName);
		}
		return humanOneLastName.compareTo(humanTwoLastName);
	}

}
