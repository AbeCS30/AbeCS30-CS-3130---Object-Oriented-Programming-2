import java.util.Comparator;

public class AssemblyOrder implements Comparator<Human>{

	@Override
	public int compare(Human o1, Human o2) {
		SortByName sortByName = new SortByName();
		if (o1 instanceof Adult) {
			if (o2 instanceof Youth) {
				return 1;
			} else if (o2 instanceof Adult) {
				return sortByName.compare(o1, o2);
			} else {
				return -1;
			}
		} else if (o1 instanceof WilliamAberhartStudent) {
			if (o2 instanceof Adult) {return -1;}
			else if (o2 instanceof WilliamAberhartStudent) {return sortByName.compare(o1, o2);}
			else if (o2 instanceof Youth) {return -1;}
			else {return -1;}
		} else if (o1 instanceof Youth) {
			if (o2 instanceof Adult) {return -1;}
			else if (o2 instanceof WilliamAberhartStudent) {return 1;}
			else if (o2 instanceof Youth) {return sortByName.compare(o1, o2);}
			else {return -1;}
		} else {
			if (o2 instanceof Youth || o2 instanceof Adult) {return 1;}
			else {return sortByName.compare(o1, o2);}
		}
	}
	
}
