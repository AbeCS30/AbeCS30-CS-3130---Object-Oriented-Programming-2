import java.time.LocalDateTime;
import java.util.Comparator;

public class Human implements Comparable {
	private Gender gender;
	private int birthYear;
	private int birthMonth;
	private int birthDay;
	private String firstName;
	private String lastName;
		
	public static SortByAge AGE_ORDER = new SortByAge();
	public static SortByName NAME_ORDER = new SortByName();
	public static AssemblyOrder ASSEMBLY_ORDER = new AssemblyOrder();
	public Human(int birthYear, int birthMonth, int birthDay, String firstName, String lastName, Gender gender) {
		this.birthYear = birthYear;
		this.birthMonth = birthMonth;
		this.birthDay = birthDay;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	}
	public int calculateCurrentAgeInYears() {
		LocalDateTime currentTime = LocalDateTime.now();
		int numYears = currentTime.getYear() - birthYear; numYears--;
		if (birthMonth < currentTime.getMonthValue()) {return numYears + 1;}
		else if (birthMonth == currentTime.getMonthValue()) {
			if (birthDay <= currentTime.getDayOfMonth()) {
				return numYears + 1;
			}
		}
		return numYears;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String newFirstName) {
		firstName = newFirstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String newLastName) {
		lastName = newLastName;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender newGender) {
		gender = newGender;
	}
	public int getBirthDay() {
		return birthDay;
	}
	public int getBirthYear() {
		return birthYear;
	}
	public int getBirthMonth() {
		return birthMonth;
	}
	public int compareTo(Object h1) {
		// TODO Auto-generated method stub
		return AGE_ORDER.compare(this, (Human)(h1));		
	}
	
}
