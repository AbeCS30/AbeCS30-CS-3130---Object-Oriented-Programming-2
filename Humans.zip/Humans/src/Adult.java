
public class Adult extends Human {
	private String placeOfWork;
	private String occupation;
	public Adult(int birthYear, int birthMonth, int birthDay, String firstName, String lastName, Gender gender, String placeOfWork, String occupation) {
		super(birthYear, birthMonth, birthDay, firstName, lastName, gender);
		this.placeOfWork = placeOfWork;
		this.occupation = occupation;
	}
	public String getPlaceOfWork() {
		return placeOfWork;
	}
	public void setPlaceOfWork(String newPlaceOfWork) {
		placeOfWork = newPlaceOfWork;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String newOccupation) {
		occupation = newOccupation;
	}

}
