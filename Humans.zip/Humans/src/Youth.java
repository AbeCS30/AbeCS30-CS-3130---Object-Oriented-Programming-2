
public class Youth extends Human {
	private int schoolGrade = -1;
	private String schoolName = "";
	public Youth(int birthYear, int birthMonth, int birthDay, String firstName, String lastName, Gender gender, int schoolGrade, String schoolName) {
		super(birthYear, birthMonth, birthDay, firstName, lastName, gender);
		this.schoolGrade = schoolGrade;
		this.schoolName = schoolName;
	}
	public Youth(int birthYear, int birthMonth, int birthDay, String firstName, String lastName, Gender gender, int schoolGrade) {
		super(birthYear, birthMonth, birthDay, firstName, lastName, gender);
		this.schoolGrade = schoolGrade;
		this.schoolName = "William Aberhart High School";
	}
	public String getSchoolName() {
		return schoolName;
	}
	public void setSchoolName(String newSchoolName) {
		schoolName = newSchoolName;
	}
	public int getSchoolGrade() {
		return schoolGrade;
	}
	public void setSchoolGrade(int newSchoolGrade) {
		schoolGrade = newSchoolGrade;
	}
}
