public class Introducer {
	public static String createPublicIntroduction(Human person) {
		try {
		String pronoun = "They";
		StringBuilder output = new StringBuilder("I am pleased to introduce ");
		output.append(person.getFirstName()).append(" ").append(person.getLastName()).append(".");
		if (person.getGender() == Gender.FEMALE) {pronoun = "She";}
		else if (person.getGender() == Gender.MALE) {pronoun = "He";}
//		output.append(" ").append(pronoun).append(" is ").append(person.calculateCurrentAgeInYears()).append(" years old.");
		if (person instanceof Youth) {
			output.append(" ").append(pronoun).append(" goes to ").append(((Youth) person).getSchoolName());
			output.append(" and is in grade ").append(((Youth)person).getSchoolGrade()).append(".");
			if (person instanceof WilliamAberhartStudent) {
				if (((WilliamAberhartStudent)person).getHoomRoomTeacher() != null) {
					output.append(" ").append(pronoun).append(" belongs to ").append(((WilliamAberhartStudent)person).getHoomRoomTeacher());
					output.append("'s homeroom, which is in room ").append(((WilliamAberhartStudent)person).getHomeRoom());
					output.append(".");
				} else {
					output.append(" Their homeroom is unknown at this time.");
				}
			}
		} else if (person instanceof Adult) {
			output.append(" ").append(pronoun).append(" works at ").append(((Adult)person).getPlaceOfWork())
			.append(" and their occupation is ").append(((Adult)person).getOccupation()).append(".");
		} 
		return output.toString();
		} catch (Exception e) {return "This person has issues and can't be introduced.";}
	}
}
